<?php
	include "header.php";
	$cid=$_REQUEST['cid'];
?>
 <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">product</li>
    </ol>
<div class="left-ads-display col-lg-12"  align="center">
    <div class="row">
		<?php
			 $q="select * from product_info where c_id=$cid";
			 $c=mysqli_query($con,$q);
			 while($a=mysqli_fetch_array($c))
			 {
		?>
		<div class="col-md-3 product-men">
			<div class="product-shoe-info shoe text-center">
			<a href="productinfo.php?pid=<?php echo $a['p_id'];?>">
				<div class="men-thumb-item">
					<img src="../Admin/upload/<?php echo $a['image']; ?>" style="height:200px; width:100%" class="img-fluid" alt="Image not found">
					
				</div>
				<div class="item-info-product">
					<h4>
						<?php echo $a['company'];?> </a>
					</h4>
						<div class="product_price">
						<div class="grid-price">
							<span class="money">Rs.<?php echo $a['price'];?></br></span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
			}
		?>
	</div>
</div>
<?php 	
	include"footer.php";
 ?>