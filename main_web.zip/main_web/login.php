<?php
	include "header.php";
	if(isset($_POST['btnok']))
	{
		$un=$_POST['nmtxt'];
		$pw=$_POST['pwtxt'];
		
		$q="SELECT * from register_tbl where name='$un' AND password='$pw'";
		$c=mysqli_query($con,$q);
	    $r=mysqli_num_rows($c);
		if($r>=1)
		{
			$_SESSION['user']=$un;
			while($rr=mysqli_fetch_array($c))
			{
				$_SESSION['user_id']=$rr['u_id'];
			}
			?>
			<script>
				alert("Successfully Login");
				window.location="index.php";
			</script>
			<?php
		}
		else
		{
			?>
			<script>
				alert("Invalid Username and Password...");
				window.location="login.php";
			</script>
		
			<?php
		}
	}	
?>

    <!--//main-content-->
    <!---->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Login</li>
    </ol>
    <!---->
    <!--// mian-content -->
    <!-- banner -->
    <section class="ab-info-main py-2">
	<center>
        <div class="container py-4">
            <h3 class="tittle text-center">Login</h3>
            <div class="row contact-main-info mt-5">
                <div class="col-md-6 contact-right-content">
                    <form action="#" method="post">
                        <input type="text" name="nmtxt" placeholder="Enter User Name" required="">
                        <input type="password" name="pwtxt" placeholder="Enter password" required="">
                        <div class="read mt-3">
                            <input type="submit" name="btnok" value="Submit"/>
							<input type="submit" name="btnok" value="Cancel"/>
							<br/><br/><a href="register.php">Create account </a>
						</div>
                    </form>
                </div>
         </div>
        </div>
	</center>
    </section>


    <!-- //contact -->
 <?php 	
	include"footer.php";
 ?>