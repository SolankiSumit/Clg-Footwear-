<?php 
	include"header1.php"
?>

<?php 
	include"footer.php"
?>