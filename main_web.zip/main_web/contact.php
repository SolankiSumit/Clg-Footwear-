<?php
	include "header.php";
	if(isset($_POST['btnok']))
{
  $nm=$_POST['nmtxt'];
  $em=$_POST['emtxt'];
  $pn=$_POST['pntxt'];
  $msg=$_POST['msgtxt'];  
  $dt = date(d/m/y);
		
  $q="INSERT INTO feedback values ('','$nm','$em','$pn','$msg','$dt=date(d/m/y)')";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
   ?>
	<script>
	alert("Feedback Sent Succesfully..");
	window.location="contact.php";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }  
}

?>
    <!--//main-content-->
    <!---->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Contact Us</li>
    </ol>
    <!---->
    <!--// mian-content -->
    <!-- banner -->
    <section class="ab-info-main py-5">
        <div class="container py-3">
            <h3 class="tittle text-center">Contact Us</h3>
            <div class="row contact-main-info mt-5">
                <div class="col-md-6 contact-right-content">
                    <form action="#" method="post">
                        <input type="text" name="nmtxt" placeholder="Name" required="">
                        <input type="Email" class="email" name="emtxt" placeholder="Email" required="">
                        <input type="text" name="pntxt" placeholder="Phone" required="">
                        <textarea name="msgtxt" placeholder="Message" required=""></textarea>
                        <div class="read mt-3">
                            <input type="submit" name="btnok" value="Submit">
                        </div>
                    </form>
                </div>
         </div>
        </div>
    </section>


    <!-- //contact -->
 <?php 	
	include"footer.php";
 ?>