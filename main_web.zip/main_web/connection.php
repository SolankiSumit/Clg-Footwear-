<?php
$con=mysqli_connect("localhost","root","","collegianfootwear_db");
?>