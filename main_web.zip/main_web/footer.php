<!-- footer -->
    <footer>
        <div class="container">
            <div class="row footer-top">
               <div class="col-lg-4 footer-grid_section_w3layouts">
                    <h2 class="logo-2 mb-lg-4 mb-3">
                        <a href="index.php">Collegian Footwear</a>
                    </h2>
                    <p>hello welcome Collegian Footwear ofjeffjoef kfeijfoejf</p>
                </div>
                <div class="col-lg-8 footer-right">
                    <div class="w3layouts-news-letter">
                        <h3 class="footer-title text-uppercase text-wh mb-lg-4 mb-3">info/ update</h3>
                        <p>By subscribing to our mailing list you will always get latest news and updates from us.</p>
                        <form action="#" method="post" class="w3layouts-newsletter">
                            <input type="email" name="Email" placeholder="Enter your email..." required="">
                            <button class="btn1"><span class="fa fa-paper-plane-o" aria-hidden="true"></span></button>
						</form>
                    </div>
                    <div class="cpy-right text-left row">
                        <p class="col-md-10">@ 2022 Developed Gp rajkot.All Rights Reserved | Design By Sumit Solanki && Drashti Makwana </p>
                        <!-- move top icon -->
                        <a href="#home" class="move-top text-right col-md-2"><span class="fa fa-long-arrow-up" aria-hidden="true"></span></a>
                        <!-- //move top icon -->
                   </div>
               </div>
			  </div>
            </div>
        </div>
		
    </footer>
    <!-- //footer -->

</body>
</html>
