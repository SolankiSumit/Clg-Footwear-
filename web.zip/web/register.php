<?php
	include"header1.php";
	
   session_start();
	include"connection.php";
	if(isset($_POST['btnok']))
	{
		$un=$_POST['nmtxt'];
		$pw=$_POST['pwtxt'];
		$em=$_POST['emtxt'];
		$cn=$_POST['cntxt'];
		$add=$_POST['adtxt'];
		$cit=$_POST['cttxt'];
		$s=$_POST['sttxt'];
		$co=$_POST['contxt'];
		$pi=$_POST['pitxt'];
		$a=$_POST['agtxt'];
		$gn=$_POST['gndtxt'];
		
		$q="insert into register_tbl values ('','$un','$pw','$em','$cn','$add','$cit','$s','$co','$pi','$a','$gn')";
		$c=mysqli_query($con,$q);
		
		if($c)
		{
			$_SESSION['admin']=$un;
			?>
			<script>
				alert("Successfully Login");
				window.location="login.php";
			</script>
			<?php
		}
		else
		{
			?>
			<script>
				alert("Invalid Username and Password...");
				window.location="register.php";
			</script>
			<?php
		}
	}	
?>

    <!--//main-content-->
    <!---->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Register</li>
    </ol>
    <!---->
    <!--// mian-content -->
    <!-- banner -->
    <section class="ab-info-main py-2">
        <div class="container py-3">
            <h3 class="tittle text-center">Register Page</h3>
            <div class="row contact-main-info mt-5">
                <div class="col-md-6 contact-right-content">
                    <form action="#" method="post">
                        <input type="text" name="nmtxt" placeholder="Enter User Name" required="">
                        <input type="text" name="pwtxt" placeholder="Enter Password" required="">
						<input type="text" name="emtxt" placeholder="Enter your Email Address" required="">
                        <input type="text" name="cntxt" placeholder="Enter your Contect" required="">
                        <input type="text" name="adtxt" placeholder="Enter your Address" required="">
                        <input type="text" name="cttxt" placeholder="Enter your City" required="">
                        <input type="text" name="sttxt" placeholder="Enter your State" required="">
                        <input type="text" name="contxt" placeholder="Enter your Country" required="">
                        <input type="text" name="pitxt" placeholder="Enter your Pin" required="">
                        <input type="text" name="agtxt" placeholder="Enter your Age" required="">
                        <input type="radio" name="gndtxt" value="male" required="" >Male &nbsp &nbsp
						<input type="radio" name="gndtxt" value="Female" required="" >Female
                        <div class="read mt-3">
                            <input type="submit" name="btnok" value="Register"/>
							<input type="submit" name="btnok" value="Cancel"/>
						</div>
                    </form>
                </div>
         </div>
        </div>
    </section>
 <?php 	
	include"footer.php";
 ?>