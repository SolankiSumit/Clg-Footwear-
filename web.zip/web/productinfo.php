<?php
 include "header1.php";
 $pid=$_REQUEST['pid'];

if(isset($_POST['btnok']))
{
  $nm=$_POST['nmtxt'];
  $uid=$_SESSION['user_id'];
  $size=$_POST[$pid];
  $qq="INSERT INTO cart_info values('','$uid','$pid','$nm','$size')";
  $c=mysqli_query($con,$qq);
  
  if($c)
	{
		?>
		<script>
			alert("Message Sent Successfully");
			window.location="cart.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert("something is wrong....please try again");
			window.location="login.php";
		</script>
		<?php
	} 
}
?>
<link href="css/rd.css" rel="stylesheet">
    
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="index.php">Home</a>
		</li>
		<li class="breadcrumb-item active">productinfo</li>
	</ol>
	<section class="ab-info-main py-md-2">
		<div class="container py-md-3">
			<h3 class="tittle text-center mb-lg-5 mb-3"> Product Page</h3>
			<?php
			
				 $q="select * from product_info where p_id='$pid'";
				 $c=mysqli_query($con,$q);
				 while($a=mysqli_fetch_array($c))
				 {
				?>
			
				<div class="left-ads-display col-lg-8">
					<div class="row">
						<div class="desc1-left col-md-6">
							<img src="../Admin/upload/<?php echo $a['image']; ?>" class="img-fluid" alt="">
						</div>
						<div class="desc1-right col-md-6 pl-lg-4">
						<form action="#" method="post">
							<h3>
							<?php 
							   $cid=$a['c_id'];
							   $qq="select * from category where id='$cid'";
							   $cc=mysqli_query($con,$qq);
							   while($rr=mysqli_fetch_array($cc))
							   {
								echo $rr['name'];   
							   }
							?>
							</h3>
							<h3>PRICE : Rs.<?php echo $a['price'];?></h3>
							<div class="available mt-3">
								<h3>DESCRIPTION : <?php echo $a['Description'];?><h3>
								<h3>COLOR : <?php echo $a['color'];?><h3>
								<h3>SIZE :</h3> 
								<table width=5%>
								<tr>
								<?php 
									$q1="select * from product_size where p_id='$pid'";
									$c1=mysqli_query($con,$q1);
									while($r1=mysqli_fetch_array($c1))
									{
										
									?>
									<td>
										<input type="radio" name="<?php echo $pid?>" value="<?php echo $r1['size'];?>" id="<?php echo $r1['size_id'];?>"/>
										<label for="<?php echo $r1['size_id'];?>">
											<?php echo $r1['size'];?>
										</label>
									</td><td> &nbsp;&nbsp;&nbsp;&nbsp; </td>
									
								
								<?php
									}
								?>
								</tr>
								</table>
								<h3>COMPANY : <?php echo $a['company'];?></h3>
								<h3>TITLE : <?php echo $a['title'];?></h3>
							</div>
					<input type="text" name="nmtxt" placeholder="Enter Quantity"> <br><br>
					<div class="col-6 ban-buttons">
						<button class="btn btn-course" type="submit" name="btnok">Add to Cart</a>
					</div>
					</form>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	 <?php
		}
	?>


<?php 	
  include"footer.php";
?>