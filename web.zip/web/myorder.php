<?php
	include"header1.php";
?>
 <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">My Order History</li>
    </ol> 
<html>  
<head>   
   <center><b> <h3> My Order History <h3></b></center>&nbsp; &nbsp; &nbsp; 
    <style> 
	
        table
		{  
            border-collapse: collapse=;  
            width: 100%;   
        }  
      th,td
	   {  
        border: 2px solid black;   
        padding: 15px;  
       }  
               
    </style>  
  </head>  
  <body>  
  <?php

	 $q="SELECT * FROM order_master where u_id";
	 $c=mysqli_query($con,$q);
	 while($a=mysqli_fetch_array($c))
	 {
	?>  
	<center>
  <table style="width:80%">  
    <tr>  
        <th>Order No:-<?PHP echo $a['o_id'];?></th>  
        <th>Order Date:-<?PHP echo $a['o_date'];?></th> 
    </tr>  
    <tr>  
        <td>Total Price:- <?PHP echo $a['total_price'];?></td>  
        <td>Total Quantity:-<?PHP echo $a['total_qty'];?></td>  
    </tr> 
	<tr>
		<td colspan=2> Address:-<?PHP echo $a ['adderess'];?></td>          
    </tr>
	    <tr>
	<table style="width:80%">
		<tr>
			<th>No</th>
			<th>Name</th>
			<th>Size</th>
			<th>Price</th>
			<th>Quantity</th>
			<th>Total</th>
		</tr>

	<?php
	$o_id=$a['o_id'];
	 $qq="SELECT * FROM order_item_detail where order_id='$o_id'";
	 $cc=mysqli_query($con,$qq);
	 while($aa=mysqli_fetch_array($cc))
	 {
	?>
		<tr>
			<th><?php echo $aa['order_item_id'];?></th> 
			 <?php
				$pid=$aa['p_id'];
			  $q1="SELECT * FROM product_info where p_id='$pid'";
	          $c1=mysqli_query($con,$q1);
	          while($a1=mysqli_fetch_array($c1))
	          {
				  $price=$a1['price'];
			  ?> 			
					
				<th><?php echo $a1['title'];?></th> 
			
			<?php
			  }
			?>
			<th><?php echo $aa['size'];?></th>
			<th><?php echo $price; ?></th> 
			<th><?php echo $aa['quantity'];?></th> 
			<th><?php echo $aa['total_price'];?></th>
		</tr>
     <?php	
	 }
	?>  
	 		</table>
	</tr>
</tr>
</table>  
</center>
<br/>
 <?php 
	 }
 ?>
</body>  
</html>  
<?php 	
	include"footer.php";
 ?>