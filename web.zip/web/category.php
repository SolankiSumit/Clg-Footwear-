<?php
	include "header.php";
?>
 <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">product</li>
    </ol>
<section class="ab-info-main py-5">
        <div class="container py-lg-3">
            <div class="ab-info-grids">
                <h3 class="tittle text-center mb-lg-5 mb-3">Category</h3>
                <div id="products" class="row view-group">
					<?php
						 $q="select * from category";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
                    <div class="item col-lg-4"><br><br>
						<div class="thumbnail card">
						<a href="product.php?cid=<?php echo $a['id']?>">
                            <div class="img-event">
                                <img class="group list-group-image img-fluid" src="../Admin/upload/<?php echo $a['image'];?>" style="height:320px; width:100%" alt="Image not found" />
                            </div>
						</a>
                            <div class="caption card-body">
                                <h3 class="group card-title inner list-group-item-heading"></h3>
                                <p class="group inner list-group-item-text">
                                    <h4><?php echo $a['name'];?></br></h4>				   
								</p>
                            </div>
                        </div>
                    </div>
					<?php
						}
					?>
				</div>
			</div>
		</div>
	</section>

<?php 	
	include"footer.php";
 ?>