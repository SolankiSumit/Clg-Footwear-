<?php
	include "header.php";
?>
    <!--//main-content-->
    <!---->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Contact Us</li>
    </ol>
    <!---->
    <!--// mian-content -->
    <!-- banner -->
    <section class="ab-info-main py-5">
        <div class="container py-3">
            <h3 class="tittle text-center">Contact Us</h3>
            <div class="row contact-main-info mt-5">
                <div class="col-md-6 contact-right-content">
                    <form action="#" method="post">
                        <input type="text" name="Name" placeholder="Name" required="">
                        <input type="password" class="email" name="Email" placeholder="Email" required="">
                        <input type="text" name="Phone no" placeholder="Phone" required="">
                        <textarea name="Message" placeholder="Message" required=""></textarea>
                        <div class="read mt-3">
                            <input type="submit" value="Submit">
                        </div>
                    </form>
                </div>
         </div>
        </div>
    </section>


    <!-- //contact -->
 <?php 	
	include"footer.php";
 ?>