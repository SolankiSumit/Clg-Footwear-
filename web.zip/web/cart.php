<?php
	include "header1.php";
	
	if(isset($_POST['btnok']))
	{
	$uid=$_SESSION['user_id'];
	$date=date('d-m-Y');
	$add=$_POST['addtxt'];
	$totalprice=$_POST['totalprice'];
	$totalqty=$_POST['totalqty'];
	
	$q="INSERT INTO order_master VALUES('','$uid','$totalqty','$totalprice','$add','$date')";
	$c=mysqli_query($con,$q);
  
	  if($c)
	  { 
		?>
		<script>
			alert("Sucessfully insert");
			window.location="myorder.php";
		</script>
		<?php

	  }	  
	  else
	  {
		?>
		<script>
			alert("Somthing Goes wrong... Please try again");
		</script>
		<?php
	  }
	}
?>
 <ol class="breadcrumb">
	<li class="breadcrumb-item">
		<a href="index.php">Home</a>
	</li>
	<li class="breadcrumb-item active">Cart</li>
</ol>
<section>

		<div class="table-responsive bs-example widget-shadow">
		<center><br/><h3>Your cart Details</h3><br/>
		<table class="table table-bordered" style="width:80%"> 
			<thead> 
				<tr> 
					<td align="center"><b>Action</b></td>
					<th>No</th> 
					<th>Size</th> 
					<th>Name</th> 
					<th>Price</th> 
					<th>Quantity</th> 
					<th>Total</th>
				</tr> 
			</thead> 
				<?php
					$k=1;
					$total=0;
					$totalqty=0;
					$uid=$_SESSION['user_id'];
					$q="select * from cart_info where u_id='$uid'";
					$c=mysqli_query($con,$q);
					while($a=mysqli_fetch_array($c))
					{
						
				?>
						<tbody> 
							<tr> 
							<td align="center">											
								<i class="fa fa-trash" style="color:red"></i>
								
							</td>											
							<td><?php echo $k; ?></td> 
							<td><?php echo $a['size_id'];?></td> 
							<?php
								$pid=$a['p_id'];
								$q1="select * from product_info where p_id='$pid'";
								$c1=mysqli_query($con,$q1);
								while($r1=mysqli_fetch_array($c1))
								{
									$p=$r1['price'];
									?>
									<td><?php echo $r1['title'];?></td> 
									<td><?php echo $r1['price'];?></td> 
						<?php
									
								}	
							?>
							<td>
							<?php 
								$q=$a['quantity']; 
								echo $q;
								$totalqty=$totalqty+$q;
							?>
							</td> 
							<td>
							<?php 
								$t=$p*$q; 
								$total=$total+$t;
								echo $t;
								?>
							</td>
							</tr> 
							<?php
							$k++;
								}
							?>
							<tr>
								<td colspan=5 rowspan=3></td>
								<td><b>Total</b></td>
								<td><b><?php echo $total;?></b></td>
							</tr>
							<tr>
								
								<td><b>Shipping Charge</b></td>
								<td><b>100</b></td>
							</tr>
							<tr>
								<td><b>Net Payable Amount</b></td>
								<td><b><?php echo $total+100;?></b></td>
							</tr>
						</tbody>
		</table>
		<div class="col-md-6 contact-right-content">
			<form action="#" method="post">
				<input type="hidden" name="totalprice" value="<?php echo $total+100; ?>"/>
				<input type="hidden" name="totalqty" value="<?php echo $totalqty; ?>"/>
					<textarea name="addtxt" rows=5 cols=30 placeholder="Delivery Address"></textarea>
			<div class="read mt-3">
				<input type="submit" value="Place Order" name="btnok"/>
			</div>
			<br/>

			</form>
		</div>
		</center>
		</div>
		</section>

<?php 	
	include "footer.php";
 ?>